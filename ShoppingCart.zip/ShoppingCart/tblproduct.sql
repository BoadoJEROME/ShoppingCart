CREATE TABLE IF NOT EXISTS `tblproduct` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `image` text NOT NULL,
  `price` double(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_code` (`code`)
)

INSERT INTO `tblproduct` (`id`, `name`, `code`, `image`, `price`) VALUES
(1, 'Nike Shoes', 'nike01', 'product-images/nike.jpg', 1500.00),
(2, 'Gel Shoes', 'gel02', 'product-images/gel.jpg', 800.00),
(3, 'Adidas shoes', 'Adidas03', 'product-images/adidas.jpg', 300.00);
